#include "headfile.h"
#include "art.h"
#include "motor.h"
#include "encoder.h"
#include "init.h"
#include "task.h"
#include "art.h"
#include "map.h"
#include "MG3512.h"
#include "menu.h"
#include "zzf.h"
#include "filter.h"
extern encoder_t enc;
extern __IO motor_t motor[4];
extern vel_plan_t vel_p_;
extern float x;
extern float y;

extern openart_t art;   // art����
extern task_t task;     //�����������
extern image_t img;     //�����ͼ��
extern debug_t debug;   // debugʱ���õĺ���
extern MapList maplist; //��ͼ����ָ�����
extern mg3512_t mg;     // �����
extern IMU_t imu;
extern CarInt_t car_i;
extern int temp;
extern menu_t menu_table[MENU_PAGES];
extern int lcd_index; // ҳ��
void (*display)(void);

int main(void)
{
        DisableGlobalIRQ();
        all_init();
        pit_interrupt_ms(PIT_CH0, 5);
        pit_interrupt_ms(PIT_CH1, 1);
        pit_interrupt_ms(PIT_CH2, 10);
        //�˴���д�û�����(���磺�����ʼ�������)
        //���ж������
        EnableGlobalIRQ(0);
        param_init();

        task.mapsize = GenerateMapList(maplist, art.Tar_x, art.Tar_y);
        while (1)
        {
                display = menu_table[lcd_index].current_operation;
                UART_printf(DATA_SEND_UART, "%f,%f,%d,%f,%f,%f\r\n", img.mean, img.var, img.edge_corner_id, img.edge_lk, img.edge_rk, img.edge_k);
                if (mt9v03x_csi_finish_flag)
                {
                        mt9v03x_csi_finish_flag = 0;
                        img.thre = otsuThreshold(mt9v03x_csi_image[0], MT9V03X_CSI_W, MT9V03X_CSI_H);
                        Turn_gray(img.thre);
                        find_up_edge(img.edge_col_max, img.edge_col_min);
                        (*display)();
                        // lcd_displayimage032_zoom(img.binimg[0], MT9V03X_CSI_W, MT9V03X_CSI_H, 160, 128);
                }

                cal_mean_var(img.edge, &img.mean, &img.var);
                // ����ױ��нǵ㣬����Ե���������ݷ����
                if (img.var > 10.0f)
                {
                        img.edge_corner_id = 160 - 1;
                        img.edge_corner = 120 - 1;
                        for (int i = img.edge_col_max - 1; i >= img.edge_col_min; i--)
                        {
                                if (img.edge[i])
                                {
                                        // ���½ǵ�ֵ
                                        img.edge_corner = img.edge[i] <= img.edge_corner ? img.edge[i] : img.edge_corner;
                                        // ���ݽǵ�ֵ���½ǵ����
                                        img.edge_corner_id = img.edge[i] <= img.edge_corner ? i : img.edge_corner_id;
                                }
                        }
                        lcd_drawpoint(img.edge_corner_id, img.edge_corner, GREEN); // 160*120
                        img.edge_lk = regression(img.edge, img.edge_col_min, img.edge_corner_id);
                        img.edge_rk = regression(img.edge, img.edge_corner_id, img.edge_col_max);

                        // ɸѡС��б��
                        img.edge_k = fabs(img.edge_lk) <= fabs(img.edge_rk) ? img.edge_lk : img.edge_rk;
                        // ���˵�б�ʺܴ�ģ���ζ��ͼƬ��������
                        img.edge_k = fabs(img.edge_k) <= 0.8f ? img.edge_k : 0.0f;
                }
                else
                {
                        img.edge_k = regression(img.edge, img.edge_col_min, img.edge_col_max);
                        // ���˵�б�ʺܴ�ģ���ζ��ͼƬ��������
                        img.edge_k = fabs(img.edge_k) <= 0.8f ? img.edge_k : 0.0f;
                }
                // img.edge_k = cal_edge_k(10.0f);
        }
}
