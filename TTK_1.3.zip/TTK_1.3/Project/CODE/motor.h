#ifndef _MOTOR_H
#define _MOTOR_H

#define PWM_MAX 50000
typedef struct
{
    float tar_speed;
    float curr_speed;
    float curr_pos;
    float tar_pos;
    double tar_x;
    double tar_y;
    float tar_angle;
    float curr_angle;
    float pwm;
} motor_t;
typedef struct
{
    float tar_speed;
    float curr_speed;
    float curr_pos;
    float tar_pos;
    double tar_x;
    double tar_y;
    float tar_angle;
    float curr_angle;
} car_t;
typedef struct
{
    float t_x;
    float time_x;
    float t_y;
    float time_y;
    float res_x;
    float res_v_x;
    float res_y;
    float res_v_y;
    float vel_p_flag;
    float k[6];
    bool end_flag_x;
    bool end_flag_y;
} vel_plan_t;
typedef struct
{
    float car_pos;
    float motor_pos[4];
    float curVel[4];
    float preVel[4];
    float delta;
} PosInt_t;
typedef struct
{
    float pos_x, pos_y;
    float curr_x, curr_y;
    float pre_x, pre_y;
    float delta;
} CarInt_t;
void motor_init(void);
void pwm_load(int flpwm, int frpwm, int brpwm, int blpwm);
void pid_pwm_load(int type);
int vel_set(float vx, float vy, float w, int i);
float x_vel_planned(double T, float deltaT, float tar_pos);
float y_vel_planned(double T, float deltaT, float tar_pos);
int motor_vel_get(float deltaT);
int motor_pos_get(float deltaT);
int car_pos_get(float deltaT);
int pos_set(double T, float deltaT, float x, float y);
#endif