/**
 * @file GY86.c
 * @author liyufan
 * @brief ʹ�ô˺���ʱ����סҪ����ɵĿ⺯������ע�͵�
 * @version 0.1
 * @date 2022-04-30
 *
 * @copyright Copyright (c) 2022
 *
 */
#include "headfile.h"
#include "GY86.h"
GY86_t gy;
/**
 * @brief
 *
 * @return int
 */
int GY86_Init(void)
{
    systick_delay_ms(100);
    //ģ��IIC��ʼ��
    simiic_init();
    // MPU6050��ʼ��
    simiic_write_reg(MPU6050_DEV_ADDR, PWR_MGMT_1, 0x00);
    simiic_write_reg(MPU6050_DEV_ADDR, SMPLRT_DIV, 0x07);
    simiic_write_reg(MPU6050_DEV_ADDR, MPU6050_CONFIG, 0x04);
    simiic_write_reg(MPU6050_DEV_ADDR, GYRO_CONFIG, 0x08);  // 500��/s,��Ӧ65.5
    simiic_write_reg(MPU6050_DEV_ADDR, ACCEL_CONFIG, 0x10); // +-8g
    simiic_write_reg(MPU6050_DEV_ADDR, User_Control, 0x00);
    simiic_write_reg(MPU6050_DEV_ADDR, INT_PIN_CFG, 0x02);
    // HMC5883��ʼ��
    simiic_read_reg(HMC5883_Addr, HMC_CFGA, SIMIIC);
    simiic_write_reg(HMC5883_Addr, HMC_MDOEReg, 0x00); //��������ģʽ
    return 0;
}

int GY86_GetData(GY86_t *data)
{
    uint8_t acc_data[6] = {0}, gyro_data[6] = {0}, hmc_data[6] = {0};
    simiic_read_regs(MPU6050_DEV_ADDR, ACCEL_XOUT_H, acc_data, 6, SIMIIC);
    data->acc_x = (float)(int16_t)(acc_data[0] << 8 | acc_data[1]);
    data->acc_y = (float)(int16_t)(acc_data[2] << 8 | acc_data[3]);
    data->acc_z = (float)(int16_t)(acc_data[4] << 8 | acc_data[5]);
    // data->acc_x = (int16)(((uint16)acc_data[0] << 8 | acc_data[1]));
    // data->acc_y = (int16)(((uint16)acc_data[2] << 8 | acc_data[3]));
    // data->acc_z = (int16)(((uint16)acc_data[4] << 8 | acc_data[5]));
    simiic_read_regs(MPU6050_DEV_ADDR, GYRO_XOUT_H, gyro_data, 6, SIMIIC);
    data->gyro_x = (float)(int16_t)(gyro_data[0] << 8 | gyro_data[1]);
    data->gyro_y = (float)(int16_t)(gyro_data[2] << 8 | gyro_data[3]);
    data->gyro_z = (float)(int16_t)(gyro_data[4] << 8 | gyro_data[5]);
    // data->gyro_x = (int16)(((uint16)gyro_data[0] << 8 | gyro_data[1]));
    // data->gyro_y = (int16)(((uint16)gyro_data[2] << 8 | gyro_data[3]));
    // data->gyro_z = (int16)(((uint16)gyro_data[4] << 8 | gyro_data[5]));
    simiic_read_regs(HMC5883_Addr, HMC_DataXHSB, hmc_data, 6, SIMIIC);
    // data->hX = (float)(int16_t)(hmc_data[0] << 8 | hmc_data[1]) + 13.814f;
    // data->hZ = ((float)(int16_t)(hmc_data[2] << 8 | hmc_data[3]) - 100.16f) * 508.07f / 415.0f;
    // data->hY = ((float)(int16_t)(hmc_data[4] << 8 | hmc_data[5]) + 134.59f) * 508.07f / 490.11f;
    data->hX = (float)(int16_t)(hmc_data[0] << 8 | hmc_data[1]) + 16.348f;
    data->hZ = ((float)(int16_t)(hmc_data[2] << 8 | hmc_data[3]) - 110.86f) * 456.37f / 366.09f;
    data->hY = ((float)(int16_t)(hmc_data[4] << 8 | hmc_data[5]) + 151.41f) * 456.37f / 435.66f;
    return 0;
}