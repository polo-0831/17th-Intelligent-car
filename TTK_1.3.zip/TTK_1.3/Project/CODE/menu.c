#include "headfile.h"
#include "menu.h"
#include "art.h"
#include "motor.h"
#include "encoder.h"
#include "init.h"
#include "task.h"
#include "art.h"
#include "map.h"
#include "MG3512.h"
extern int temp;
extern int temp1;
extern openart_t art;   // art����
extern task_t task;     // �����������
extern image_t img;     // �����ͼ��
extern debug_t debug;   // debugʱ���õĺ���
extern MapList maplist; // ��ͼ����ָ�����
extern mg3512_t mg;     // �����

extern encoder_t enc;
extern __IO motor_t motor[4];
extern vel_plan_t vel_p_;

menu_t menu_table[MENU_PAGES] =
    {
        // ��ǰҳ���ϣ��£���һҳ����һҳ
        {0, 0, 0, 1, 6, (*main_menu)},
        {1, 0, 0, 2, 0, (*task_debug)},
        {2, 0, 0, 3, 1, (*weitiao_debug)},
        {3, 0, 0, 4, 2, (*map_debug)},
        {4, 0, 0, 5, 3, (*zzf_image)},
        {5, 1, 1, 6, 4, (*thremode_change)},
        {6, 2, 2, 0, 5, (*thre_change)},
};

/**
 * @brief
 *
 */
// ��ʾ���˵�
void main_menu(void)
{
    lcd_clear(WHITE);
    lcd_showstr(0, 1, "0----main  menu-----");
    lcd_showstr(0, 2, "1----task debug-----");
    lcd_showstr(0, 3, "2--weitiao debug----");
    lcd_showstr(0, 4, "3----map debug------");
    lcd_showstr(0, 5, "4-showing zzf image-");
    lcd_showstr(0, 6, "5change some params-");
}
// ��ʾtask��ֵ
void task_debug(void)
{
    lcd_clear(WHITE);

    lcd_showstr(0, 1, "1----task debug-----");

    lcd_showstr(0, 2, "start");
    lcd_showint32(100, 2, task.start, 3);

    lcd_showstr(0, 3, "close");
    lcd_showint32(60, 3, task.close_x, 3);
    lcd_showint32(100, 3, task.close_y, 3);

    lcd_showstr(0, 4, "cur");
    lcd_showint32(60, 4, task.cur_x, 3);
    lcd_showint32(100, 4, task.cur_y, 3);

    lcd_showstr(0, 5, "next");
    lcd_showint32(60, 5, task.next_x, 3);
    lcd_showint32(100, 5, task.next_y, 3);

    lcd_showstr(0, 6, "t_xy");
    lcd_showfloat(60, 6, vel_p_.time_x, 3, 1);
    lcd_showfloat(100, 6, vel_p_.time_y, 3, 1);

    lcd_showstr(0, 7, "mg.end_flag");
    lcd_showint32(100, 7, mg.end_flag, 5);
}
// ��ʾ΢���������
void weitiao_debug(void)
{
    lcd_clear(WHITE);
    lcd_showstr(0, 1, "2--weitiao debug----");

    lcd_showstr(0, 2, "start");
    lcd_showint32(100, 2, task.start, 3);

    lcd_showstr(0, 3, "image");
    lcd_showint32(60, 3, art.image_x, 3);
    lcd_showint32(100, 3, art.image_y, 3);

    lcd_showstr(0, 4, "edge_k");
    lcd_showfloat(100, 4, img.edge_k, 3, 1);

    lcd_showstr(0, 6, "count");
    lcd_showint32(100, 6, task.count, 5);
}
// ��ʾ��ͼ����
void map_debug(void)
{
    lcd_clear(WHITE);

    lcd_showstr(0, 1, "3----map debug------");

    lcd_showstr(0, 2, "tar[0]");
    lcd_showint32(60, 2, art.Tar_x[0], 2);
    lcd_showint32(100, 2, art.Tar_y[0], 2);

    lcd_showstr(0, 3, "tar[1]");
    lcd_showint32(60, 3, art.Tar_x[1], 2);
    lcd_showint32(100, 3, art.Tar_y[1], 2);

    lcd_showstr(0, 4, "tar[2]");
    lcd_showint32(60, 4, art.Tar_x[2], 2);
    lcd_showint32(100, 4, art.Tar_y[2], 2);

    lcd_showstr(0, 6, "mapsize");
    lcd_showint32(100, 6, task.mapsize, 5);

    lcd_showstr(0, 7, "count");
    lcd_showint32(100, 7, task.count, 5);
}

// ��ʾ�����ͼ��
void zzf_image(void)
{
    lcd_showstr(0, 1, "4-showing zzf image-");

    // lcd_displayimage032_zoom(mt9v03x_csi_image[0], MT9V03X_CSI_W, MT9V03X_CSI_H, 160, 128);
    lcd_displayimage032_zoom(img.binimg[0], MT9V03X_CSI_W, MT9V03X_CSI_H, 160, 128);
    // lcd_displayimage032(mt9v03x_csi_image[0], MT9V03X_CSI_W, MT9V03X_CSI_H);
    // lcd_displayimage032(img.binimg[0], MT9V03X_CSI_W, MT9V03X_CSI_H); // 160, 128
}

// �޸���ֵģʽ
void thremode_change(void)
{
    lcd_clear(WHITE);
    lcd_showstr(0, 1, "------thr mode------");

    lcd_showint32(100, 2, img.mode, 3);
    lcd_showstr(0, 2, "thr mode");
    lcd_showint32(100, 3, img.thre, 3);
    lcd_showstr(0, 3, "fixed thr");
}

// �޸Ĺ̶���ֵ
void thre_change(void)
{
    lcd_clear(WHITE);
    lcd_showstr(0, 1, "-----fixed thr------");

    lcd_showint32(100, 2, img.mode, 3);
    lcd_showstr(0, 2, "thr mode");
    lcd_showint32(100, 3, img.thre, 3);
    lcd_showstr(0, 3, "fixed thr");
}