#ifndef _ZZF_H
#define _ZZF_H
int zzf_correct(float tar, float curr);
void Turn_gray(uint8 thre);
uint8 otsuThreshold(uint8 *image, uint8 col, uint8 row);
float regression(const int edge[], int startline, int endline);
float cal_timek(float x, float y);
void cal_mean_var(int *data, float *mean, float *var);
void find_up_edge(int col_min, int col_max);
float cal_edge_k(float var_threshold);
void image(void);
#endif