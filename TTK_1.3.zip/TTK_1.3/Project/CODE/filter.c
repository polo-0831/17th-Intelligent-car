#include "headfile.h"
#include "filter.h"
#include "GY86.h"
#include "math.h"
#define PI 3.1415926f
#define delta_T 0.005f // ��ʱ��5ms
extern GY86_t gy;
IMU_t imu;
Offset_t offset;
Q_info_t Q_info = {1, 0, 0, 0}; //��Ԫ����ʼ��
/**
 * @brief ����ƽ�������仯
 */
float FISR(float x)
{
    uint32_t i = 0;
    float y, halfx;
    halfx = 0.5 * x;
    i = *(uint32_t *)&x;
    i = 0x5f3759df - (i >> 1);
    y = *(float *)&i;
    y = y * (1.5 - halfx * y * y);
    return y;
}

/**
 * @brief ��������
 *
 */
void ImuOffsetInit(void)
{
    //�?�?初�?�化�?0
    offset.ax = 0;
    offset.ay = 0;
    offset.az = 0;
    offset.gx = 0;
    offset.gy = 0;
    offset.gz = 0;
    offset.hx = 0;
    offset.hy = 0;
    offset.hz = 0;

    for (uint16_t i = 0; i < 2000; ++i)
    {
        GY86_GetData(&gy);
        offset.ax += gy.acc_x;
        offset.ay += gy.acc_y;
        offset.az += gy.acc_z;
        offset.gx += gy.gyro_x;
        offset.gy += gy.gyro_y;
        offset.gz += gy.gyro_z;
        offset.hx += gy.hX;
        offset.hy += gy.hY;
        offset.hz += gy.hZ;
        systick_delay_ms(1);
    }
    offset.ax /= 2000.0f;
    offset.ay /= 2000.0f;
    offset.az /= 2000.0f;
    offset.gx /= 2000.0f;
    offset.gy /= 2000.0f;
    offset.gz /= 2000.0f;
    offset.hx /= 2000.0f;
    offset.hy /= 2000.0f;
    offset.hz /= 2000.0f;
}
/**
 * @brief
 *
 * @tips:
 */
void IMU_GetAngle(void)
{
    float alpha = 0.3;
    GY86_GetData(&gy);
    //һ�׻����˲�
    imu.ax = gy.acc_x * alpha / 4096 + imu.ax * (1 - alpha);
    imu.ay = gy.acc_y * alpha / 4096 + imu.ay * (1 - alpha);
    imu.az = gy.acc_z * alpha / 4096 + imu.az * (1 - alpha);
    imu.gx = (gy.gyro_x - offset.gx) * PI / 180.0f / 65.5f;
    imu.gy = (gy.gyro_y - offset.gy) * PI / 180.0f / 65.5f;
    imu.gz = (gy.gyro_z - offset.gz) * PI / 180.0f / 65.5f;

    float halfT = 0.5 * delta_T; // �������
    static float vx, vy, vz;
    static float aex, aey, aez;
    static float mex, mey, mez;
    static float aexInt, aeyInt, aezInt;
    static float mexInt, meyInt, mezInt;
    float hx, hy, hz, bx, bz;
    float wx, wy, wz;

    float q0 = Q_info.q0;
    float q1 = Q_info.q1;
    float q2 = Q_info.q2;
    float q3 = Q_info.q3;

    float q0q0 = q0 * q0;
    float q0q1 = q0 * q1;
    float q0q2 = q0 * q2;
    float q0q3 = q0 * q3;
    float q1q1 = q1 * q1;
    float q1q2 = q1 * q2;
    float q1q3 = q1 * q3;
    float q2q2 = q2 * q2;
    float q2q3 = q2 * q3;
    float q3q3 = q3 * q3;

    if (imu.ax * imu.ay * imu.az == 0)
        return;

    float norm = FISR(imu.ax * imu.ax + imu.ay * imu.ay + imu.az * imu.az);
    // PRINTF("%f\r\n",imu.ax);
    // PRINTF("%f\r\n", norm);
    // PRINTF("OK\r\n");
    imu.ax = imu.ax * norm;
    imu.ay = imu.ay * norm;
    imu.az = imu.az * norm;

    norm = FISR(gy.hX * gy.hX + gy.hY * gy.hY + gy.hZ * gy.hZ);
    gy.hX = gy.hX * norm;
    gy.hY = gy.hY * norm;
    gy.hZ = gy.hZ * norm;

    hx = 2.0f * gy.hX * (0.5f - q2q2 - q3q3) + 2.0f * gy.hY * (q1q2 - q0q3) + 2.0f * gy.hZ * (q1q3 + q0q2);
    hy = 2.0f * gy.hX * (q1q2 + q0q3) + 2.0f * gy.hY * (0.5f - q1q1 - q3q3) + 2.0f * gy.hZ * (q2q3 - q0q1);
    hz = 2.0f * gy.hX * (q1q3 - q0q2) + 2.0f * gy.hY * (q2q3 + q0q1) + 2.0f * gy.hZ * (0.5f - q1q1 - q2q2);

    bx = sqrt((hx * hx) + (hy * hy));
    bz = hz;

    wx = 2.0f * bx * (0.5f - q2q2 - q3q3) + 2.0f * bz * (q1q3 - q0q2);
    wy = 2.0f * bx * (q1q2 - q0q3) + 2.0f * bz * (q0q1 + q2q3);
    wz = 2.0f * bx * (q0q2 + q1q3) + 2.0f * bz * (0.5f - q1q1 - q2q2);

    vx = 2 * (q1q3 - q0q2);
    vy = 2 * (q0q1 + q2q3);
    vz = q0q0 - q1q1 - q2q2 + q3q3;

    aex = imu.ay * vz - imu.az * vy;
    aey = imu.az * vx - imu.ax * vz;
    aez = imu.ax * vy - imu.ay * vx;
    //
    aexInt += aex;
    aeyInt += aey;
    aezInt += aez;

    mex = (gy.hY * wz - gy.hZ * wy);
    mey = (gy.hZ * wx - gy.hX * wz);
    mez = (gy.hX * wy - gy.hY * wx);

    mexInt += mex;
    meyInt += mey;
    mezInt += mez;

    imu.gx += (aex * Acc_Kp + aexInt * Acc_Ki) + (mex * Mag_Kp + mexInt * Mag_Ki);
    imu.gy += (aey * Acc_Kp + aeyInt * Acc_Ki) + (mey * Mag_Kp + meyInt * Mag_Ki);
    imu.gz += (aez * Acc_Kp + aezInt * Acc_Ki) + (mez * Mag_Kp + mezInt * Mag_Ki);

    q0 = q0 + (-q1 * imu.gx - q2 * imu.gy - q3 * imu.gz) * halfT;
    q1 = q1 + (q0 * imu.gx + q2 * imu.gz - q3 * imu.gy) * halfT;
    q2 = q2 + (q0 * imu.gy - q1 * imu.gz + q3 * imu.gx) * halfT;
    q3 = q3 + (q0 * imu.gz + q1 * imu.gy - q2 * imu.gx) * halfT;

    norm = FISR(q0 * q0 + q1 * q1 + q2 * q2 + q3 * q3);
    Q_info.q0 = q0 * norm;
    Q_info.q1 = q1 * norm;
    Q_info.q2 = q2 * norm;
    Q_info.q3 = q3 * norm;

    //��ȡ���յ�ŷ����
    imu.pitch = asin(2 * Q_info.q0 * Q_info.q2 - 2 * Q_info.q1 * Q_info.q3) * 180 / PI;
    imu.roll = atan2(2 * Q_info.q2 * Q_info.q3 + 2 * Q_info.q0 * Q_info.q1, -2 * Q_info.q1 * Q_info.q1 - 2 * Q_info.q2 * Q_info.q2 + 1) * 180 / PI;
    imu.yaw = atan2(2 * Q_info.q1 * Q_info.q2 + 2 * Q_info.q0 * Q_info.q3, -2 * Q_info.q2 * Q_info.q2 - 2 * Q_info.q3 * Q_info.q3 + 1) * 180 / PI;
}