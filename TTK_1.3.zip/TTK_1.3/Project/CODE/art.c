#include "headfile.h"
#include "art.h"
#include "pid.h"
#include "task.h"
#include "motor.h"
#include "stdarg.h"
#include "stdio.h"
#include "encoder.h"
#include "pid.h"

uint8 uart1_buff;
uint8 UART1_i = 0;
uint8 uart1_data[200];
lpuart_transfer_t uart1_receivexfer;
lpuart_handle_t uart1_g_lpuartHandle;

uint8 uart4_buff;
uint8 UART4_i = 0;
uint8 uart4_data[200];
lpuart_transfer_t uart4_receivexfer;
lpuart_handle_t uart4_g_lpuartHandle;

uint8 uart8_buff;
uint8 UART8_i = 0;
uint8 uart8_data[200];
lpuart_transfer_t uart8_receivexfer;
lpuart_handle_t uart8_g_lpuartHandle;

extern openart_t art;
extern debug_t debug;
extern task_t task;

extern encoder_t enc;
extern __IO motor_t motor[4];
extern vel_plan_t vel_p_;

extern pid_t image_x_pid;
extern pid_t image_y_pid;
img_vel_t img_v;

// ���ܵ�ͼ���ѭ������
int i = 1;
int j = 1;

void openart1_callback(LPUART_Type *base, lpuart_handle_t *handle, status_t status, void *userData)
{

    if (kStatus_LPUART_RxIdle == status)
    {
        uart1_data[UART1_i++] = uart1_buff;
    }
    if (uart1_buff == 'Z')
    {
        memset(uart1_data, 0, sizeof(uart1_data));
        UART1_i = 0;
    }
    uart1_buff = 0;
    // ͼƬ΢��

    if (uart1_data[3] == 'x')
    {
        art.image_x = (int)(uart1_data[0] - 48) * 100 + (uart1_data[1] - 48) * 10 + (uart1_data[2] - 48);
    }
    if (uart1_data[7] == 'y')
    {
        art.image_y = (int)(uart1_data[4] - 48) * 100 + (uart1_data[5] - 48) * 10 + (uart1_data[6] - 48);
    }
    // ��ͼʶ��

    if (uart1_data[2] == 'X')
    {
        art.Tar_x[i] = (int)(uart1_data[0] - 48) * 10 + (uart1_data[1] - 48);
        i++;
    }
    if (uart1_data[2] == 'Y')
    {
        art.Tar_y[j] = (int)(uart1_data[0] - 48) * 10 + (uart1_data[1] - 48);
        j++;
    }

    // ʶ��Ĵ���С��
    if (uart1_data[3] == 'm')
    {
        art.recognize_buff[0] = (int)(uart1_data[1] - 48);
        art.recognize_buff[1] = (int)(uart1_data[2] - 48);
    }

    handle->rxDataSize = uart1_receivexfer.dataSize;
    handle->rxData = uart1_receivexfer.data;
}
/**
 * @brief  Uart4
 *
 * @param base
 * @param handle
 * @param status
 * @param userData
 */
void openart2_callback(LPUART_Type *base, lpuart_handle_t *handle, status_t status, void *userData)
{
    if (kStatus_LPUART_RxIdle == status)
    {
        uart4_data[UART4_i++] = uart4_buff;
    }

    handle->rxDataSize = uart4_receivexfer.dataSize;
    handle->rxData = uart4_receivexfer.data;
}

void wifi8_callback(LPUART_Type *base, lpuart_handle_t *handle, status_t status, void *userData)
{
    if (kStatus_LPUART_RxIdle == status)
    {
        uart8_data[UART8_i++] = uart8_buff;
    }
    if (uart8_buff == 'Z')
    {
        memset(uart8_data, 0, sizeof(uart8_data));
        UART8_i = 0;
    }
    uart8_buff = 0;
    // ����ֹͣ
    task.start = 0;

    handle->rxDataSize = uart8_receivexfer.dataSize;
    handle->rxData = uart8_receivexfer.data;
}

int UART_printf(UARTN_enum uartn, const char *fmt, ...)
{
    va_list ap;
    va_start(ap, fmt);
    int length, i;
    char buffer[128];
    length = vsnprintf(buffer, 128, fmt, ap);
    for (i = 0; i < length; i++)
    {
        uart_putchar(uartn, *(buffer + i));
    }
    va_end(ap);
    return length;
}
//-------------------------------------------------------------------------------------------------------------------
//  @brief      �����Ӿ�������ת��ģ�� ���ͺ���
//  @param      uartn               ����ö��
//  @param      second              ����ʱ�����룩
//  @param      msecond             ����ʱ�������룩
//  @param      pos_x               X����
//  @param      pos_y               Y����
//  @param      cg                  ���
//  Sample usage:
//-------------------------------------------------------------------------------------------------------------------
void send_msg(UARTN_enum uartn, uint16 second, uint16 msecond, uint8 pos_x, uint8 pos_y, category_enum cg)
{
    uint8 msg[18] = {0};
    //ʱ����Ϣ
    msg[0] = second / 100 + '0';
    msg[1] = second % 100 / 10 + '0';
    msg[2] = second % 10 + '0';
    msg[3] = '.';
    msg[4] = msecond / 100 + '0';
    msg[5] = msecond % 100 / 10 + '0';
    msg[6] = msecond % 10 + '0';

    //����X��Ϣ
    msg[7] = ' ';
    msg[8] = pos_x / 10 + '0';
    msg[9] = pos_x % 10 + '0';

    //����Y��Ϣ
    msg[10] = ' ';
    msg[11] = pos_y / 10 + '0';
    msg[12] = pos_y % 10 + '0';

    //��� ������Ϣ
    msg[13] = ' ';
    msg[14] = (uint8)cg / 6 + '0';

    //��� С����Ϣ
    msg[15] = ' ';
    msg[16] = (uint8)cg % 6 + '0';

    msg[17] = '\n';
    uart_putbuff(uartn, msg, 18);
}
/**
 * @brief ΢���ٶȹ滮
 *
 * @param slewVal
 * @param refVal
 * @param slewRate_speedup
 * @param slewRate_speeddown
 * @return int16_t
 */
int16_t Speed_slew(float *slewVal, float refVal, float slewRate_speedup, float slewRate_speeddown)
{
    static float diff = 0;
    diff = refVal - *slewVal;
    if (diff >= slewRate_speedup)
    {
        *slewVal += slewRate_speedup;
        return (1);
    }
    else if (-diff >= slewRate_speeddown)
    {
        *slewVal -= slewRate_speeddown;
        return (-1);
    }
    else
    {
        *slewVal = refVal;
        return (0);
    }
}
/**
 * @brief ͼ�����������ٶ�
 *
 * @param vx
 * @param vy
 * @param w
 */
void image_vel_set(float vx, float vy, float w)
{
    static float k_speedup, k_speeddown;

    k_speedup = 1.5f / 100.0f;
    k_speeddown = 1.5f / 100.0f;
    Speed_slew(&img_v.soft_vx, vx, k_speedup, k_speeddown);
    Speed_slew(&img_v.soft_vy, vy, k_speedup, k_speeddown);
    Speed_slew(&img_v.soft_w, w, 10.0f * k_speedup, 10.0f * k_speeddown);
    motor[0].tar_speed = img_v.soft_vy + img_v.soft_vx - img_v.soft_w * 0.18f; //��ǰ
    motor[1].tar_speed = img_v.soft_vy - img_v.soft_vx + img_v.soft_w * 0.18f; //��ǰ
    motor[2].tar_speed = img_v.soft_vy + img_v.soft_vx + img_v.soft_w * 0.18f; //�Һ�
    motor[3].tar_speed = img_v.soft_vy - img_v.soft_vx - img_v.soft_w * 0.18f; //���
}

/**
 * @brief  artͼƬ΢��
 *
 * @param tar_x
 * @param tar_y
 * @param curr_x
 * @param curr_y
 */
void Fine_Tuning(float tar_x, float tar_y, float curr_x, float curr_y)
{

    art.Vx = pid_image_x(&image_x_pid, tar_x, curr_x);
    art.Vy = -pid_image_y(&image_y_pid, tar_y, curr_y);
    // inverseSolution(art.Vx, art.Vy, 0);
    for (size_t i = 0; i < 4; i++)
    {
        image_vel_set(art.Vx, art.Vy, 0.0f);
    }
}
