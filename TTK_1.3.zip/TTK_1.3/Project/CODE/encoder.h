#ifndef _ENCODER_H
#define _ENCODER_H
typedef struct
{
    int16_t encoder[4];
    int32_t sum_encoder[4];
} encoder_t;

void encoder_init(void);
void encoder_count(void);
void encoder_clear(void);
void encoder_dir(void);
void encoder_count_get(void);
void sum_encoder_count_get(void);
void sum_encoder_count_clear(void);
#endif