#ifndef __MAP_H
#define __MAP_H

typedef struct MapNode
{
    int mapx;
    int mapy;
    int mapnum;
    struct MapNode *next;

} MapNode, *MapList;

MapNode *MapList_Init();
int AppendMapList(MapList L, int map_x, int map_y, int map_num);
void FindClosest(MapList L, int *close_x, int *close_y, int now_x, int now_y);
int DeleteMapNode(MapList L, int num);
int GenerateMapList(MapList L, int Tar_x[200], int Tar_y[200]);

#endif