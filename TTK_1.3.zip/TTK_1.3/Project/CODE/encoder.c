#include "headfile.h"
#include "encoder.h"

encoder_t enc;
/**
 * @brief ��������ʼ��
 *
 */
void encoder_init(void)
{
    qtimer_quad_init(QTIMER_1, QTIMER1_TIMER0_C0, QTIMER1_TIMER1_C1);
    qtimer_quad_init(QTIMER_1, QTIMER1_TIMER2_C2, QTIMER1_TIMER3_C24);
    qtimer_quad_init(QTIMER_2, QTIMER2_TIMER0_C3, QTIMER2_TIMER3_C25);
    qtimer_quad_init(QTIMER_3, QTIMER3_TIMER2_B18, QTIMER3_TIMER3_B19);
}
/**
 * @brief ����������
 *
 */
void encoder_count(void)
{
    enc.encoder[0] = qtimer_quad_get(QTIMER_1, QTIMER1_TIMER0_C0);
    enc.encoder[1] = qtimer_quad_get(QTIMER_1, QTIMER1_TIMER2_C2);
    enc.encoder[2] = qtimer_quad_get(QTIMER_2, QTIMER2_TIMER0_C3);
    enc.encoder[3] = qtimer_quad_get(QTIMER_3, QTIMER3_TIMER2_B18);
}
/**
 * @brief ��������������
 *
 */
void encoder_clear(void)
{
    qtimer_quad_clear(QTIMER_1, QTIMER1_TIMER0_C0);
    qtimer_quad_clear(QTIMER_1, QTIMER1_TIMER2_C2);
    qtimer_quad_clear(QTIMER_2, QTIMER2_TIMER0_C3);
    qtimer_quad_clear(QTIMER_3, QTIMER3_TIMER2_B18);
}
/**
 * @brief ������������
 *
 */
void encoder_dir(void)
{
    enc.encoder[1] = -enc.encoder[1];
    enc.encoder[2] = -enc.encoder[2];
}

/**
 * @brief ��ȡ��������ֵ
 *
 */
void encoder_count_get(void)
{
    encoder_count();
    encoder_dir();
    encoder_clear();
}
/**
 * @brief �ۼ��������
 *
 */
void sum_encoder_count_get(void)
{
    for (size_t i = 0; i < 4; i++)
    {
        enc.sum_encoder[i] += enc.encoder[i];
    }
}
/**
 * @brief
 *
 */
void sum_encoder_count_clear(void)
{
    for (size_t i = 0; i < 4; i++)
    {
        enc.sum_encoder[i] = 0;
    }
}