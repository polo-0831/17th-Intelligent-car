#include "headfile.h"
#include "pid.h"

pid_t vel[4];
pid_t diff[4];
pid_t pos[2];
pid_t image_x_pid;
pid_t image_y_pid;
pid_t zzf;
pid_t yellow;
pid_t yaw;
/**
 * @brief PID��ʼ��
 *
 * @param pid
 * @param kp
 * @param ki
 * @param kd
 * @param kis
 * @param deltaT
 * @param range
 */
void pid_init(pid_t *pid, float kp, float ki, float kd, float kis, float deltaT, float range)
{
    pid->kp = kp;
    pid->ki = ki;
    pid->kd = kd;

    pid->kis = kis;

    pid->deltaT = deltaT;
    pid->range = range;
    pid->i = 0.0f;
}

/**
 * @brief �ٶȻ�PID
 *
 * @param pid
 * @param target
 * @param curr
 * @return float
 */
float y = 0.0f;
float pid_vel(pid_t *pid, float target, float curr)
{
    float err = target - curr;
    float derr = (err - pid->prev) / pid->deltaT;

    pid->prev = err;
    pid->i += err * pid->deltaT;

    float output = pid->kp * err + pid->ki * pid->i + pid->kd * derr;

    if (output > pid->range)
    {
        pid->i += pid->kis * (pid->range - output) * pid->deltaT;

        return pid->range;
    }
    else if (output < -pid->range)
    {
        pid->i -= pid->kis * (pid->range + output) * pid->deltaT;

        return -pid->range;
    }
    y = output;
    return output;
}
/**
 * @brief λ�û�PID
 *
 * @param pid
 * @param target
 * @param curr
 * @return float
 */
float pid_pos(pid_t *pid, float target, float curr)
{
    float err = target - curr;
    float derr = (err - pid->prev) / pid->deltaT;

    pid->prev = err;
    pid->i += err * pid->deltaT;

    float output = pid->kp * err + pid->ki * pid->i + pid->kd * derr;

    if (output > pid->range)
    {
        pid->i += pid->kis * (pid->range - output) * pid->deltaT;

        return pid->range;
    }
    else if (output < -pid->range)
    {
        pid->i -= pid->kis * (pid->range + output) * pid->deltaT;
        return -pid->range;
    }

    return output;
}
/**
 * @brief ת��PID
 *
 * @param pid
 * @param target
 * @param curr
 * @return float
 */
float pid_yaw(pid_t *pid, float target, float curr)
{
    float err = target - curr;
    float derr = (err - pid->prev) / pid->deltaT;

    pid->prev = err;
    pid->i += err * pid->deltaT;

    float output = pid->kp * err + pid->ki * pid->i + pid->kd * derr;

    if (output > pid->range)
    {
        pid->i += pid->kis * (pid->range - output) * pid->deltaT;

        return pid->range;
    }
    else if (output < -pid->range)
    {
        pid->i -= pid->kis * (pid->range + output) * pid->deltaT;
        return -pid->range;
    }

    return output;
}

/**
 * @brief ���ٻ�PID
 *
 * @param pid
 * @param target
 * @param curr
 * @return float
 */
float pid_diff(pid_t *pid, float target, float curr)
{
    float err = target - curr;
    float derr = (err - pid->prev) / pid->deltaT;

    pid->prev = err;
    pid->i += err * pid->deltaT;

    float output = pid->kp * err + pid->ki * pid->i + pid->kd * derr;

    if (output > pid->range)
    {
        pid->i += pid->kis * (pid->range - output) * pid->deltaT;

        return pid->range;
    }
    else if (output < -pid->range)
    {
        pid->i -= pid->kis * (pid->range + output) * pid->deltaT;
        return -pid->range;
    }
    return output;
}
/**
 * @brief ͼ��X��PID,art����
 *
 * @param pid
 * @param target
 * @param curr
 * @return float
 */
float pid_image_x(pid_t *pid, float target, float curr)
{
    float err = curr - target;
    float derr = (err - pid->prev) / pid->deltaT;

    pid->prev = err;
    pid->i += err * pid->deltaT;

    float output = pid->kp * err + pid->ki * pid->i + pid->kd * derr;

    if (output > pid->range)
    {
        pid->i += pid->kis * (pid->range - output) * pid->deltaT;

        return pid->range;
    }
    else if (output < -pid->range)
    {
        pid->i -= pid->kis * (pid->range + output) * pid->deltaT;

        return -pid->range;
    }

    return output;
}
/**
 * @brief ͼ��Y��PID��art����
 *
 * @param pid
 * @param target
 * @param curr
 * @return float
 */
float pid_image_y(pid_t *pid, float target, float curr)
{
    float err = curr - target;
    float derr = (err - pid->prev) / pid->deltaT;

    pid->prev = err;
    pid->i += err * pid->deltaT;

    float output = pid->kp * err + pid->ki * pid->i + pid->kd * derr;

    if (output > pid->range)
    {
        pid->i += pid->kis * (pid->range - output) * pid->deltaT;

        return pid->range;
    }
    else if (output < -pid->range)
    {
        pid->i -= pid->kis * (pid->range + output) * pid->deltaT;

        return -pid->range;
    }

    return output;
}
/**
 * @brief �����ع��׼ֵPID
 *
 * @param pid
 * @param target
 * @param curr
 * @return float
 */
float pid_zzf(pid_t *pid, float target, float curr)
{
    float err = curr - target;
    float derr = (err - pid->prev) / pid->deltaT;

    pid->prev = err;
    pid->i += err * pid->deltaT;

    float output = pid->kp * err + pid->ki * pid->i + pid->kd * derr;

    if (output > pid->range)
    {
        pid->i += pid->kis * (pid->range - output) * pid->deltaT;

        return pid->range;
    }
    else if (output < -pid->range)
    {
        pid->i -= pid->kis * (pid->range + output) * pid->deltaT;

        return -pid->range;
    }

    return output;
}

/**
 * @brief  ��ɫ�߻ع��׼ֵPID
 *
 * @param pid
 * @param target
 * @param curr
 * @return float
 */
float pid_yellow(pid_t *pid, float target, float curr)
{
    float err = curr - target;
    float derr = (err - pid->prev) / pid->deltaT;

    pid->prev = err;
    pid->i += err * pid->deltaT;

    float output = pid->kp * err + pid->ki * pid->i + pid->kd * derr;

    if (output > pid->range)
    {
        pid->i += pid->kis * (pid->range - output) * pid->deltaT;

        return pid->range;
    }
    else if (output < -pid->range)
    {
        pid->i -= pid->kis * (pid->range + output) * pid->deltaT;

        return -pid->range;
    }

    return output;
}