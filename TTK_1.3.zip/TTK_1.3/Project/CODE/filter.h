#ifndef _FILTER_H
#define _FILTER_H

#define Acc_Kp (0.3f)
#define Acc_Ki (0.001f)
#define Mag_Kp (0.0f) // 130.0f
#define Mag_Ki (0.0f) // 0.01f
typedef struct
{
    float ax, ay, az;
    float gx, gy, gz;
    float hx, hy, hz;
    float I_ex, I_ey, I_ez;
    float pitch, roll, yaw; //欧拉�?
} IMU_t;
typedef struct
{
    float q0, q1, q2, q3;
} Q_info_t;
typedef struct
{
    float ax, ay, az;
    float gx, gy, gz;
    float hx, hy, hz;
} Offset_t;
void ImuOffsetInit(void);
void IMU_GetAngle(void);
#endif