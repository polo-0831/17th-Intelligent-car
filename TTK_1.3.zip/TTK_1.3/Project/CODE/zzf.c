#include "headfile.h"
#include "zzf.h"
#include "pid.h"
#include "art.h"
#include "task.h"
#include "encoder.h"
#include "motor.h"
#include "map.h"
#include "MG3512.h"

extern openart_t art;   // art数据
extern task_t task;     //任务调度数据
extern image_t img;     //总钻风图像
extern debug_t debug;   // debug时所用的函数
extern MapList maplist; //地图链表指针变量
extern mg3512_t mg;     // 电磁铁
extern pid_t zzf;
extern int lcd_index; // 页码
extern void (*display)(void);
/**
 * @brief 总钻风矫正车身
 *
 * @param tar
 * @param curr
 * @return int
 */
int zzf_correct(float tar, float curr)
{
    float pid_err = pid_zzf(&zzf, tar, curr);
    for (size_t i = 0; i < 4; i++)
    {
        image_vel_set(0.0f, 0.0f, pid_err);
    }
    return 0;
}

// 总钻风阈值化函数
// 输出二值图像bining[][]
void Turn_gray(uint8 thre)
{
    for (int i = 0; i < MT9V03X_CSI_H; i++)
    {
        for (int j = 0; j < MT9V03X_CSI_W; j++)
        {
            if (mt9v03x_csi_image[i][j] > thre)
                img.binimg[i][j] = 255;
            else
                img.binimg[i][j] = 0;
        }
    }
}

uint8 otsuThreshold(uint8 *image, uint8 col, uint8 row)
{
#define GrayScale 256
    uint8 line_width1 = col;
    uint8 height = row;
    int pixelCount[GrayScale];
    float pixelPro[GrayScale];
    int i, j, pixelSum = line_width1 * height;
    uint8 threshold = 0;
    uint8 *data = image; //指向像素数据的指针

    memset(pixelCount, 0, sizeof(pixelCount));
    memset(pixelPro, 0, sizeof(pixelPro));

    //统计灰度级中每个像素在整幅图像中的个数
    for (i = 0; i < height; i++)
    {
        for (j = 0; j < line_width1; j++)
        {
            pixelCount[(int)data[i * line_width1 + j]]++; //将像素值作为计数数组的下标
        }
    }

    //计算每个像素在整幅图像中的比例
    float maxPro = 0.0;
    for (i = 0; i < GrayScale; i++)
    {
        pixelPro[i] = (float)pixelCount[i] / pixelSum;
        if (pixelPro[i] > maxPro)
        {
            maxPro = pixelPro[i];
        }
    }

    //遍历灰度级[0,255]
    float w0, w1, u0tmp, u1tmp, u0, u1, u, deltaTmp, deltaMax = 0;
    for (i = 0; i < GrayScale; i++) // i作为阈值
    {
        w0 = w1 = u0tmp = u1tmp = u0 = u1 = u = deltaTmp = 0;
        for (j = 0; j < GrayScale; j++)
        {
            if (j <= i) //背景部分
            {
                w0 += pixelPro[j];
                u0tmp += j * pixelPro[j];
            }
            else //前景部分
            {
                w1 += pixelPro[j];
                u1tmp += j * pixelPro[j];
            }
        }
        u0 = u0tmp / w0;
        u1 = u1tmp / w1;
        u = u0tmp + u1tmp;
        deltaTmp = w0 * pow((u0 - u), 2) + w1 * pow((u1 - u), 2);
        if (deltaTmp > deltaMax)
        {
            deltaMax = deltaTmp;
            threshold = i;
        }
    }
    return threshold;
}

float regression(const int edge[], int startline, int endline)
{
    /************************************线性回归计算中线斜率************************************/
    // y = Bx+A
    int i = 0, SumX = 0, SumY = 0, SumLines = 0;
    float SumUp = 0, SumDown = 0, avrX = 0, avrY = 0, B, A;
    SumLines = endline - startline; // startline 为开始行， //endline 结束行 //SumLines

    for (i = startline; i < endline; i++)
    {
        SumX += i;
        SumY += edge[i]; //这里Middle_black为存放中线的数组
    }
    avrX = SumX / SumLines; // X的平均值
    avrY = SumY / SumLines; // Y的平均值
    SumUp = 0;
    SumDown = 0;
    for (i = startline; i < endline; i++)
    {
        SumUp += (edge[i] - avrY) * (i - avrX);
        SumDown += (i - avrX) * (i - avrX);
    }
    if (SumDown == 0)
        B = 0;
    else
        B = (SumUp / SumDown);
    A = (SumY - B * SumX) / SumLines; //截距
    return B;                         //返回斜率
}

/**
 * @brief 计算时间系数
 * @version TTK1.0
 *
 */
float cal_timek(float x, float y)
{
    float d = sqrt(x * x + y * y);
    if (d < 2.0f)
        return 0.0371 * powf(d, 4) + -0.5321 * powf(d, 2) + 2.5804;
    else
        return 1.0f;
}
/**
 * @brief 计算边缘数据的均值和方差
 * @version TTK1.0
 *
 */
void cal_mean_var(int *data, float *mean, float *var)
{
    // 边缘数组里可能含有0值，干扰方差计算，datasize表示非零的valid值
    int *t = data, sum = 0, datasize = 0;
    float com = 0;
    for (int i = 0; i < 160; i++)
    {
        if (*(t + i))
        {
            sum += *(t + i);
            datasize++;
        }
    }
    *mean = sum * 1.0 / datasize;
    for (int i = 0; i < 160; i++)
    {
        if (*(t + i))
        {
            com += (*(t + i) - *mean) * (*(t + i) - *mean);
        }
    }
    *var = com / datasize;
}

/**
 * @brief 提取上部分ROI区域，在colmax和colmin列之间从上到下寻找上边界
 * @version TTK1.0
 *
 */
void find_up_edge(int col_max, int col_min)
{
    for (int j = col_max - 1; j >= col_min; j--)
    {
        for (int i = 0; i < 80; i++)
        {
            if (img.binimg[i][j] == 0 && img.binimg[i + 1][j] == 255 && img.binimg[i + 2][j] == 255)
            {
                lcd_drawpoint(j, i, RED); // 160*120
                img.edge[j] = i;
                break;
            }
            else
            {
                img.edge[j] = 0;
            }
        }
    }
}

/**
 * @brief 计算有效的边界斜率
 * @version TTK1.0
 *
 */
float cal_edge_k(float var_threshold)
{
    float edge_k;
    // 如果底边有角点，即边缘数组内数据方差大
    if (img.var > var_threshold)
    {
        img.edge_corner_id = 160 - 1;
        img.edge_corner = 120 - 1;
        for (int i = img.edge_col_max - 1; i >= img.edge_col_min; i--)
        {
            if (img.edge[i])
            {
                // 更新角点值
                img.edge_corner = img.edge[i] <= img.edge_corner ? img.edge[i] : img.edge_corner;
                // 根据角点值更新角点序号
                img.edge_corner_id = img.edge[i] <= img.edge_corner ? i : img.edge_corner_id;
            }
        }
        lcd_drawpoint(img.edge_corner_id, img.edge_corner, GREEN); // 160*120
        img.edge_lk = regression(img.edge, img.edge_col_min, img.edge_corner_id);
        img.edge_rk = regression(img.edge, img.edge_corner_id, img.edge_col_max);

        // 筛选小的斜率
        edge_k = fabs(img.edge_lk) <= fabs(img.edge_rk) ? img.edge_lk : img.edge_rk;
        // 过滤掉斜率很大的，意味着图片被创歪了
        edge_k = fabs(edge_k) <= 0.8f ? edge_k : 0.0f;
    }
    else
    {
        edge_k = regression(img.edge, img.edge_col_min, img.edge_col_max);
        // 过滤掉斜率很大的，意味着图片被创歪了
        edge_k = fabs(edge_k) <= 0.8f ? edge_k : 0.0f;
    }
    return edge_k;
}

void image(void)
{
    if (mt9v03x_csi_finish_flag)
    {
        mt9v03x_csi_finish_flag = 0;
        img.thre = otsuThreshold(mt9v03x_csi_image[0], MT9V03X_CSI_W, MT9V03X_CSI_H);
        Turn_gray(img.thre);
        find_up_edge(img.edge_col_min, img.edge_col_max);
        if (lcd_index == 4)
            (*display)();
    }

    cal_mean_var(img.edge, &img.mean, &img.var);
    img.edge_k = cal_edge_k(10.0f);
}