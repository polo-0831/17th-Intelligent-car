#include "headfile.h"
#include "art.h"
#include "motor.h"
#include "encoder.h"
#include "init.h"
#include "task.h"
#include "art.h"
#include "map.h"
#include "MG3512.h"
#include "menu.h"

#define debug_task 0    //??debug
#define debug_weitiao 0 //?????????debug
#define debug_map 0

extern encoder_t enc;
extern __IO motor_t motor[4];
extern vel_plan_t vel_p_;
extern float x;
extern float y;

extern openart_t art;   // art����
extern task_t task;     //�����������
extern image_t img;     //�����ͼ��
extern debug_t debug;   // debugʱ���õĺ���
extern MapList maplist; //��ͼ����ָ�����
extern mg3512_t mg;
extern int temp;
extern menu_t menu_table[4];
extern int lcd_index;
void (*display)(void);
int main(void)
{
        DisableGlobalIRQ();
        all_init();
        pit_interrupt_ms(PIT_CH0, 5);
        pit_interrupt_ms(PIT_CH1, 1);
        pit_interrupt_ms(PIT_CH2, 10);
        //�˴���д�û�����(���磺�����ʼ�������)

        //���ж������
        EnableGlobalIRQ(0);
        task.start = 0;
        art.image_x = 0;
        art.image_y = 0;
        task.cur_x = 0;
        task.cur_y = -1;
        // task.cur_x = 6;
        // task.cur_y = 6;
        art.recognize_buff[0] = 1;

        art.Tar_x[1] = 6;
        art.Tar_x[2] = 9;
        art.Tar_x[3] = 16;
        art.Tar_x[4] = 24;
        art.Tar_x[5] = 30;
        art.Tar_x[6] = 19;
        art.Tar_x[7] = 10;
        art.Tar_x[8] = 7;
        art.Tar_x[9] = 10;
        art.Tar_x[10] = 16;
        art.Tar_x[11] = 30;

        art.Tar_y[1] = 6;
        art.Tar_y[2] = 3;
        art.Tar_y[3] = 4;
        art.Tar_y[4] = 6;
        art.Tar_y[5] = 4;
        art.Tar_y[6] = 13;
        art.Tar_y[7] = 13;
        art.Tar_y[8] = 16;
        art.Tar_y[9] = 19;
        art.Tar_y[10] = 17;
        art.Tar_y[11] = 21;

        maplist = MapList_Init();
        task.mapsize = GenerateMapList(maplist, art.Tar_x, art.Tar_y);
        while (1)
        {
                // lcd_clear(WHITE);
                display = menu_table[lcd_index].current_operation;
                (*display)();
                // lcd_showint32(60, 2, temp, 3);

                // lcd_showstr(0, 2, "close");
                //  UART_printf(DATA_SEND_UART, "%d,%d,%d\r\n", vel_p_.end_flag_x, vel_p_.end_flag_y, task.period);
                //  UART_printf(DATA_SEND_UART, "%d,%d,%d,%d,%d,%d,%d\r\n", task.start, art.recognize_buff[0], task.FindClosest_flag, task.cur_x, task.cur_y, task.close_x, task.close_y);
                //  if (mt9v03x_csi_finish_flag)
                //  {
                //          mt9v03x_csi_finish_flag = 0;
                //          img.thre = otsuThreshold(mt9v03x_csi_image[0], MT9V03X_CSI_W, MT9V03X_CSI_H);
                //          Turn_gray(img.thre);

                //         // ????��??
                //         for (int j = 100; j > 49; j--)
                //         {
                //                 for (int i = MT9V03X_CSI_H - 1; i > 2; i--)
                //                 {
                //                         if (img.binimg[i][j] == 0 && img.binimg[i - 1][j] == 255 && img.binimg[i - 2][j] == 255)
                //                         {
                //                                 lcd_drawpoint(j, i, RED);
                //                                 img.edge_d[j] = i; //?��?��?????
                //                                 break;
                //                         }
                //                 }
                //         }

                //         // lcd_displayimage032_zoom(mt9v03x_csi_image[0], MT9V03X_CSI_W, MT9V03X_CSI_H, 160, 128);
                //         lcd_displayimage032(img.binimg[0], MT9V03X_CSI_W, MT9V03X_CSI_H); // 160, 128
                // }
                // img.d_edge_k = regression(img.edge_d, 50, 100);

#if debug_task
                lcd_showstr(0, 2, "close");
                lcd_showint32(60, 2, task.close_x, 3);
                lcd_showint32(100, 2, task.close_y, 3);

                lcd_showstr(0, 3, "cur");
                lcd_showint32(60, 3, task.cur_x, 3);
                lcd_showint32(100, 3, task.cur_y, 3);

                lcd_showstr(0, 4, "next");
                lcd_showint32(60, 4, task.next_x, 3);
                lcd_showint32(100, 4, task.next_y, 3);

                lcd_showstr(0, 5, "t_xy");
                lcd_showfloat(60, 5, vel_p_.time_x, 3, 1);
                lcd_showfloat(100, 5, vel_p_.time_y, 3, 1);

                lcd_showstr(0, 6, "T");
                lcd_showfloat(100, 6, 2 * 0.2 * sqrt(task.next_x * task.next_x + task.next_y * task.next_y), 3, 1);

                lcd_showstr(0, 7, "mg.end_flag");
                lcd_showint32(100, 7, mg.end_flag, 5);
#endif
#if debug_weitiao
                lcd_showstr(0, 2, "image");
                lcd_showint32(60, 2, art.image_x, 3);
                lcd_showint32(100, 2, art.image_y, 3);

                lcd_showstr(0, 6, "count");
                lcd_showint32(100, 6, task.count, 5);

#endif
#if debug_map
                lcd_showstr(0, 2, "tar[0]");
                lcd_showint32(60, 2, art.Tar_x[0], 2);
                lcd_showint32(100, 2, art.Tar_y[0], 2);

                lcd_showstr(0, 3, "tar[1]");
                lcd_showint32(60, 3, art.Tar_x[1], 2);
                lcd_showint32(100, 3, art.Tar_y[1], 2);

                lcd_showstr(0, 4, "tar[2]");
                lcd_showint32(60, 4, art.Tar_x[2], 2);
                lcd_showint32(100, 4, art.Tar_y[2], 2);

                lcd_showstr(0, 5, "bench angle");
                lcd_showint32(100, 5, art.benchmark_errangle, 2);

                lcd_showstr(0, 6, "mapsize");
                lcd_showint32(100, 6, task.mapsize, 5);

                lcd_showstr(0, 7, "count");
                lcd_showint32(100, 7, task.count, 5);

#endif
        }
}
