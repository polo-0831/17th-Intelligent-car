#include "headfile.h"
#include "isr.h"
#include "motor.h"
#include "encoder.h"
#include "pid.h"
#include "art.h"
#include "MG3512.h"
#include "task.h"
#include "menu.h"
extern vel_plan_t vel_p_;
extern encoder_t enc;
extern CarInt_t car_i;

extern openart_t art; // art����
extern task_t task;   //�����������
extern image_t img;   //�����ͼ��
extern debug_t debug; // debugʱ���õĺ���
extern mg3512_t mg;
extern menu_t menu_table[4];
int lcd_index = 0;

void CSI_IRQHandler(void)
{
    CSI_DriverIRQHandler(); //����SDK�Դ����жϺ��� ���������������������õĻص�����
    __DSB();                //����ͬ������
}
void PIT_IRQHandler(void)
{
    if (PIT_FLAG_GET(PIT_CH0))
    {
        PIT_FLAG_CLEAR(PIT_CH0);
        encoder_count_get();
        sum_encoder_count_get();
        motor_vel_get(0.005);
        // vel_set(0.7f, 0.0f, 0.0f, 0);
        // vel_set(0.7f, 0.0f, 0.0f, 1);
        // vel_set(0.7f, 0.0f, 0.0f, 2);
        // vel_set(0.7f, 0.0f, 0.0f, 3);
        // vel_set(0.0f, 0.5f, 0.0f, 0);
        // vel_set(0.0f, 0.5f, 0.0f, 1);
        // vel_set(0.0f, 0.5f, 0.0f, 2);
        // vel_set(0.0f, 0.5f, 0.0f, 3);

        pid_pwm_load(3);
    }

    if (PIT_FLAG_GET(PIT_CH1))
    {
        PIT_FLAG_CLEAR(PIT_CH1);
        // task.count++;
    }

    if (PIT_FLAG_GET(PIT_CH2))
    {
        PIT_FLAG_CLEAR(PIT_CH2);
        car_pos_get(0.01);
        // Task_Flow();

        // if (task.start == 1)
        // {
        //     Pick(0.8f, 0.01f, 1);
        //     if (mg.end_flag)
        //     {
        //         task.start = 2;
        //         mg.end_flag = false;
        //     }
        // }
        // if (task.start == 2)
        // {
        //     Pick(0.8f, 0.01f, 0);
        //     if (mg.end_flag)
        //     {
        //         task.start = 1;
        //         mg.end_flag = false;
        //     }
        // }

        // if (count >= 0 && count <= 2500)
        // {
        //     car_pos_get(0.01);
        //     pos_set(2.0f, 0.01f, 1.0f, 1.0f);
        // }
        // if (count > 2500 && count < 3000)
        // {
        //     vel_p_.end_flag_x = false;
        //     vel_p_.end_flag_y = false;
        //     car_i.pos_x = 0.0f;
        //     car_i.pos_y = 0.0f;
        //     vel_p_.res_y = 0;
        //     vel_p_.res_v_y = 0;
        //     vel_p_.res_x = 0;
        //     vel_p_.res_v_x = 0;
        //     // car_pos_get(0.01);
        //     // pos_set(2.0f, 0.01f, 0.0f, 0.0f);
        // }
        // if (count >= 3000 && count < 5500)
        // {
        //     car_pos_get(0.01);
        //     pos_set(2.0f, 0.01f, -1.0f, -1.0f);
        // }
    }

    if (PIT_FLAG_GET(PIT_CH3))
    {
        PIT_FLAG_CLEAR(PIT_CH3);
    }

    __DSB();
}
int temp = 0;
void GPIO2_Combined_16_31_IRQHandler(void)
{
    //��ʱ����

    systick_delay_ms(20);
    // lcd_clear(WHITE);
    if (GET_GPIO_FLAG(key_down))
    {
        CLEAR_GPIO_FLAG(key_down);
        __DSB();
        lcd_index = menu_table[lcd_index].down;
        if (lcd_index == 1)
        {
            temp--;
        }
        // count++;
        // task.start_send_map = 1;
    }
    if (GET_GPIO_FLAG(key_enter))
    {
        CLEAR_GPIO_FLAG(key_enter);
        __DSB();
        // lcd_clear(WHITE);
        lcd_index = menu_table[lcd_index].enter;
        // temp++;
    }
    if (GET_GPIO_FLAG(key_back))
    {
        CLEAR_GPIO_FLAG(key_back);
        __DSB();
        // lcd_clear(WHITE);
        lcd_index = menu_table[lcd_index].back;
        // temp--;
    }
}

void GPIO2_Combined_0_15_IRQHandler(void)
{
    //��ʱ����
    systick_delay_ms(20);
    if (GET_GPIO_FLAG(key_up))
    {
        CLEAR_GPIO_FLAG(key_up);
        __DSB();
        // lcd_clear(WHITE);
        lcd_index = menu_table[lcd_index].up;
        if (lcd_index == 1)
        {
            temp++;
        }
    }

    if (GET_GPIO_FLAG(MT9V03X_VSYNC_PIN))
    {
        //���������־λ����־λ��mt9v03x_vsync�����ڲ������
        if (CAMERA_GRAYSCALE == flexio_camera_type)
            mt9v03x_vsync();
    }
    if (GET_GPIO_FLAG(SCC8660_VSYNC_PIN))
    {
        //���������־λ����־λ��scc8660_vsync�����ڲ������
        if (CAMERA_COLOR == flexio_camera_type)
            scc8660_vsync();
    }
}

/*
GPIO3_Combined_0_15_IRQHandler
���жϺ���Ĭ�ϱ�SD�������빦��ռ�ã������Ҫgpio�жϽ���ʹ������IO
���߲�ʹ��SD�Ŀ����Խ�fsl_sdmmc_host.c�е� SDMMCHOST_CARD_DETECT_GPIO_INTERRUPT_HANDLER����ע�͵�����

*/

/*
�жϺ������ƣ��������ö�Ӧ���ܵ��жϺ���
Sample usage:��ǰ���������ڶ�ʱ���ж�
void PIT_IRQHandler(void)
{
    //��������־λ
    __DSB();
}
�ǵý����жϺ������־λ
CTI0_ERROR_IRQHandler
CTI1_ERROR_IRQHandler
CORE_IRQHandler
FLEXRAM_IRQHandler
KPP_IRQHandler
TSC_DIG_IRQHandler
GPR_IRQ_IRQHandler
LCDIF_IRQHandler
CSI_IRQHandler
PXP_IRQHandler
WDOG2_IRQHandler
SNVS_HP_WRAPPER_IRQHandler
SNVS_HP_WRAPPER_TZ_IRQHandler
SNVS_LP_WRAPPER_IRQHandler
CSU_IRQHandler
DCP_IRQHandler
DCP_VMI_IRQHandler
Reserved68_IRQHandler
TRNG_IRQHandler
SJC_IRQHandler
BEE_IRQHandler
PMU_EVENT_IRQHandler
Reserved78_IRQHandler
TEMP_LOW_HIGH_IRQHandler
TEMP_PANIC_IRQHandler
USB_PHY1_IRQHandler
USB_PHY2_IRQHandler
ADC1_IRQHandler
ADC2_IRQHandler
DCDC_IRQHandler
Reserved86_IRQHandler
Reserved87_IRQHandler
GPIO1_INT0_IRQHandler
GPIO1_INT1_IRQHandler
GPIO1_INT2_IRQHandler
GPIO1_INT3_IRQHandler
GPIO1_INT4_IRQHandler
GPIO1_INT5_IRQHandler
GPIO1_INT6_IRQHandler
GPIO1_INT7_IRQHandler
GPIO1_Combined_0_15_IRQHandler
GPIO1_Combined_16_31_IRQHandler
GPIO2_Combined_0_15_IRQHandler
GPIO2_Combined_16_31_IRQHandler
GPIO3_Combined_0_15_IRQHandler
GPIO3_Combined_16_31_IRQHandler
GPIO4_Combined_0_15_IRQHandler
GPIO4_Combined_16_31_IRQHandler
GPIO5_Combined_0_15_IRQHandler
GPIO5_Combined_16_31_IRQHandler
WDOG1_IRQHandler
RTWDOG_IRQHandler
EWM_IRQHandler
CCM_1_IRQHandler
CCM_2_IRQHandler
GPC_IRQHandler
SRC_IRQHandler
Reserved115_IRQHandler
GPT1_IRQHandler
GPT2_IRQHandler
PWM1_0_IRQHandler
PWM1_1_IRQHandler
PWM1_2_IRQHandler
PWM1_3_IRQHandler
PWM1_FAULT_IRQHandler
SEMC_IRQHandler
USB_OTG2_IRQHandler
USB_OTG1_IRQHandler
XBAR1_IRQ_0_1_IRQHandler
XBAR1_IRQ_2_3_IRQHandler
ADC_ETC_IRQ0_IRQHandler
ADC_ETC_IRQ1_IRQHandler
ADC_ETC_IRQ2_IRQHandler
ADC_ETC_ERROR_IRQ_IRQHandler
PIT_IRQHandler
ACMP1_IRQHandler
ACMP2_IRQHandler
ACMP3_IRQHandler
ACMP4_IRQHandler
Reserved143_IRQHandler
Reserved144_IRQHandler
ENC1_IRQHandler
ENC2_IRQHandler
ENC3_IRQHandler
ENC4_IRQHandler
TMR1_IRQHandler
TMR2_IRQHandler
TMR3_IRQHandler
TMR4_IRQHandler
PWM2_0_IRQHandler
PWM2_1_IRQHandler
PWM2_2_IRQHandler
PWM2_3_IRQHandler
PWM2_FAULT_IRQHandler
PWM3_0_IRQHandler
PWM3_1_IRQHandler
PWM3_2_IRQHandler
PWM3_3_IRQHandler
PWM3_FAULT_IRQHandler
PWM4_0_IRQHandler
PWM4_1_IRQHandler
PWM4_2_IRQHandler
PWM4_3_IRQHandler
PWM4_FAULT_IRQHandler
Reserved171_IRQHandler
GPIO6_7_8_9_IRQHandler*/
