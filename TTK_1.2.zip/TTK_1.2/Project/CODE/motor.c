#include "headfile.h"
#include "motor.h"
#include "encoder.h"
#include "pid.h"

__IO motor_t motor[4];
vel_plan_t vel_p_;
PosInt_t position;
car_t car;
CarInt_t car_i;

extern pid_t vel[4];
extern encoder_t enc;
extern pid_t diff[4];
extern pid_t pos[2];
/**
 * @brief �����ʼ��
 *
 */
void motor_init(void)
{
    gpio_init(D2, GPO, 1, GPIO_PIN_CONFIG);
    pwm_init(PWM1_MODULE3_CHA_D0, 20000, 0);

    gpio_init(D3, GPO, 0, GPIO_PIN_CONFIG);
    pwm_init(PWM1_MODULE3_CHB_D1, 20000, 0);

    gpio_init(D14, GPO, 0, GPIO_PIN_CONFIG);
    pwm_init(PWM1_MODULE0_CHA_D12, 20000, 0);

    gpio_init(D15, GPO, 1, GPIO_PIN_CONFIG);
    pwm_init(PWM1_MODULE0_CHB_D13, 20000, 0);
}
/**
 * @brief װ��PWM
 *
 * @param flpwm
 * @param frpwm
 * @param brpwm
 * @param blpwm
 */
void pwm_load(int flpwm, int frpwm, int brpwm, int blpwm)
{
    if (flpwm >= 0)
    {
        gpio_set(D15, 1);
        pwm_duty(PWM1_MODULE0_CHB_D13, myabs(flpwm));
    }
    else
    {
        gpio_set(D15, 0);
        pwm_duty(PWM1_MODULE0_CHB_D13, myabs(flpwm));
    }
    if (frpwm >= 0)
    {
        gpio_set(D14, 0);
        pwm_duty(PWM1_MODULE0_CHA_D12, myabs(frpwm));
    }
    else
    {
        gpio_set(D14, 1);
        pwm_duty(PWM1_MODULE0_CHA_D12, myabs(frpwm));
    }
    if (brpwm >= 0)
    {
        gpio_set(D3, 0);
        pwm_duty(PWM1_MODULE3_CHB_D1, myabs(brpwm));
    }
    else
    {
        gpio_set(D3, 1);
        pwm_duty(PWM1_MODULE3_CHB_D1, myabs(brpwm));
    }

    if (blpwm >= 0)
    {
        gpio_set(D2, 1);
        pwm_duty(PWM1_MODULE3_CHA_D0, myabs(blpwm));
    }
    else
    {
        gpio_set(D2, 0);
        pwm_duty(PWM1_MODULE3_CHA_D0, myabs(blpwm));
    }
}
/**
 * @brief
 *
 * @param type  1ֱ�ߣ�2����
 */
void pid_pwm_load(int type)
{
    if (type == 1)
    {
        motor[0].pwm = pid_vel(&vel[0], motor[0].tar_speed, motor[0].curr_speed) - pid_diff(&diff[0], 0.0f, abs(enc.sum_encoder[0]) - abs(enc.sum_encoder[1]));
        motor[1].pwm = pid_vel(&vel[1], motor[1].tar_speed, motor[1].curr_speed) + pid_diff(&diff[0], 0.0f, abs(enc.sum_encoder[0]) - abs(enc.sum_encoder[1]));
        motor[2].pwm = pid_vel(&vel[2], motor[2].tar_speed, motor[2].curr_speed) - pid_diff(&diff[1], 0.0f, abs(enc.sum_encoder[2]) - abs(enc.sum_encoder[3]));
        motor[3].pwm = pid_vel(&vel[3], motor[3].tar_speed, motor[3].curr_speed) + pid_diff(&diff[1], 0.0f, abs(enc.sum_encoder[2]) - abs(enc.sum_encoder[3]));

        // motor[0].pwm = pid_vel(&vel[0], motor[0].tar_speed, motor[0].curr_speed) - pid_diff(&diff[0], 0.0f, motor[0].curr_speed - motor[1].curr_speed);
        // motor[1].pwm = pid_vel(&vel[1], motor[1].tar_speed, motor[1].curr_speed) + pid_diff(&diff[0], 0.0f, motor[0].curr_speed - motor[1].curr_speed);
        // motor[2].pwm = pid_vel(&vel[2], motor[2].tar_speed, motor[2].curr_speed) - pid_diff(&diff[1], 0.0f, motor[2].curr_speed - motor[3].curr_speed);
        // motor[3].pwm = pid_vel(&vel[3], motor[3].tar_speed, motor[3].curr_speed) + pid_diff(&diff[1], 0.0f, motor[2].curr_speed - motor[3].curr_speed);

        // motor[0].pwm = pid_vel(&vel[0], motor[0].tar_speed, motor[0].curr_speed);
        // motor[1].pwm = pid_vel(&vel[1], motor[1].tar_speed, motor[1].curr_speed);
        // motor[2].pwm = pid_vel(&vel[2], motor[2].tar_speed, motor[2].curr_speed);
        // motor[3].pwm = pid_vel(&vel[3], motor[3].tar_speed, motor[3].curr_speed);
    }
    if (type == 2)
    {

        // motor[0].pwm = pid_vel(&vel[0], motor[0].tar_speed, motor[0].curr_speed) - pid_diff(&diff[2], 0.0f, fabs(motor[0].curr_speed) - fabs(motor[3].curr_speed));
        // motor[1].pwm = pid_vel(&vel[1], motor[1].tar_speed, motor[1].curr_speed) + pid_diff(&diff[2], 0.0f, fabs(motor[0].curr_speed) - fabs(motor[3].curr_speed));
        // motor[2].pwm = pid_vel(&vel[2], motor[2].tar_speed, motor[2].curr_speed) - pid_diff(&diff[3], 0.0f, fabs(motor[1].curr_speed) - fabs(motor[2].curr_speed));
        // motor[3].pwm = pid_vel(&vel[3], motor[3].tar_speed, motor[3].curr_speed) + pid_diff(&diff[3], 0.0f, fabs(motor[1].curr_speed) - fabs(motor[2].curr_speed));
        motor[0].pwm = pid_vel(&vel[0], motor[0].tar_speed, motor[0].curr_speed) - pid_diff(&diff[2], 25.0f, abs(enc.sum_encoder[0]) - abs(enc.sum_encoder[3]));
        motor[3].pwm = pid_vel(&vel[3], motor[3].tar_speed, motor[3].curr_speed) + pid_diff(&diff[2], 25.0f, abs(enc.sum_encoder[0]) - abs(enc.sum_encoder[3]));
        motor[1].pwm = pid_vel(&vel[1], motor[1].tar_speed, motor[1].curr_speed) + pid_diff(&diff[3], 25.0f, abs(enc.sum_encoder[1]) - abs(enc.sum_encoder[2]));
        motor[2].pwm = pid_vel(&vel[2], motor[2].tar_speed, motor[2].curr_speed) - pid_diff(&diff[3], 25.0f, abs(enc.sum_encoder[1]) - abs(enc.sum_encoder[2]));
    }
    if (type == 3)
    {
        motor[0].pwm = pid_vel(&vel[0], motor[0].tar_speed, motor[0].curr_speed);
        motor[1].pwm = pid_vel(&vel[1], motor[1].tar_speed, motor[1].curr_speed);
        motor[2].pwm = pid_vel(&vel[2], motor[2].tar_speed, motor[2].curr_speed);
        motor[3].pwm = pid_vel(&vel[3], motor[3].tar_speed, motor[3].curr_speed);
    }

    pwm_load((int)motor[0].pwm, (int)motor[1].pwm, (int)motor[2].pwm, (int)motor[3].pwm);
}
/**
 * @brief X���ٶȹ滮
 *
 * @param T
 * @param deltaT
 * @param tar_pos
 * @return float
 */
float x_vel_planned(double T, float deltaT, float tar_pos)
{
    vel_p_.k[3] = 10.0f * tar_pos / pow(T, 3.0f);
    vel_p_.k[4] = -15.0f * tar_pos / pow(T, 4.0f);
    vel_p_.k[5] = 6.0f * tar_pos / pow(T, 5.0f);
    vel_p_.time_x = (vel_p_.t_x++) * deltaT;
    if (vel_p_.time_x <= T && vel_p_.end_flag_x == false)
    {
        vel_p_.res_x = vel_p_.k[3] * pow(vel_p_.time_x, 3) + vel_p_.k[4] * pow(vel_p_.time_x, 4) + vel_p_.k[5] * pow(vel_p_.time_x, 5);
        vel_p_.res_v_x = 3 * vel_p_.k[3] * pow(vel_p_.time_x, 2) + 4 * vel_p_.k[4] * pow(vel_p_.time_x, 3) + 5 * vel_p_.k[5] * pow(vel_p_.time_x, 4);
    }
    if (vel_p_.time_x > T && vel_p_.end_flag_x == false)
    {
        vel_p_.time_x = T;
    }
    if (fabs(vel_p_.res_x - tar_pos) <= 0.001f)
    {
        vel_p_.res_x = tar_pos;
        vel_p_.t_x = 0;
        vel_p_.end_flag_x = true;
    }
    return vel_p_.res_x;
}
/**
 * @brief Y���ٶȹ滮
 *
 * @param T
 * @param deltaT
 * @param tar_pos
 * @return float
 */
float y_vel_planned(double T, float deltaT, float tar_pos)
{

    vel_p_.k[3] = 10.0f * tar_pos / pow(T, 3.0f);
    vel_p_.k[4] = -15.0f * tar_pos / pow(T, 4.0f);
    vel_p_.k[5] = 6.0f * tar_pos / pow(T, 5.0f);
    vel_p_.time_y = (vel_p_.t_y++) * deltaT;
    if (vel_p_.time_y <= T && vel_p_.end_flag_y == false)
    {
        vel_p_.res_y = vel_p_.k[3] * pow(vel_p_.time_y, 3) + vel_p_.k[4] * pow(vel_p_.time_y, 4) + vel_p_.k[5] * pow(vel_p_.time_y, 5);
        vel_p_.res_v_y = 3 * vel_p_.k[3] * pow(vel_p_.time_y, 2) + 4 * vel_p_.k[4] * pow(vel_p_.time_y, 3) + 5 * vel_p_.k[5] * pow(vel_p_.time_y, 4);
    }
    if (vel_p_.time_y > T && vel_p_.end_flag_y == false)
    {
        vel_p_.time_y = T;
    }
    if (fabs(vel_p_.res_y - tar_pos) <= 0.001f)
    {
        vel_p_.res_y = tar_pos;
        vel_p_.t_y = 0;
        vel_p_.end_flag_y = true;
    }
    return vel_p_.res_y;
}

/**
 * @brief ��ȡ���ӵ�ǰ�ٶ�
 *
 * @return int
 */
int motor_vel_get(float deltaT)
{

    motor[0].curr_speed = (float)enc.encoder[0] / deltaT / 2350 * 0.06f * 3.141592f;
    motor[1].curr_speed = (float)enc.encoder[1] / deltaT / 2350 * 0.06f * 3.141592f;
    motor[2].curr_speed = (float)enc.encoder[2] / deltaT / 2350 * 0.06f * 3.141592f;
    motor[3].curr_speed = (float)enc.encoder[3] / deltaT / 2350 * 0.06f * 3.141592f;
    return 0;
}
// TODO: ���ӻ�û�е�ÿһ��������
/**
 * @brief �����˶�ѧ����
 *
 * @param vx
 * @param vy
 * @param w
 * @return int
 */
int vel_set(float vx, float vy, float w, int i)
{
    if (i == 0)
    {
        motor[0].tar_speed = vy + vx - w * 0.18f; //��ǰ
    }
    else if (i == 1)
    {

        motor[1].tar_speed = vy - vx + w * 0.18f; //��ǰ
    }
    else if (i == 2)
    {

        motor[2].tar_speed = vy + vx + w * 0.18f; //�Һ�
    }
    else if (i == 3)
    {

        motor[3].tar_speed = vy - vx - w * 0.18f; //���
    }
    return 0;
}
/**
 * @brief ��ȡ�����˶�����
 *
 * @param deltaT
 * @return int
 */
int motor_pos_get(float deltaT)
{
    position.delta = deltaT;
    for (size_t i = 0; i < 4; i++)
    {
        position.curVel[i] = motor[i].curr_speed;
        position.motor_pos[i] += ((position.preVel[i]) + (position.curVel[i])) / 2 * position.delta;
        position.preVel[i] = position.curVel[i];
        //��ȡ���ӵ�ǰλ��
        motor[i].curr_pos = position.motor_pos[i];
    }
    return 0;
}

/**
 * @brief ��ȡС���˶�����
 *
 * @param deltaT
 * @return int
 */
int car_pos_get(float deltaT)
{
    car_i.delta = deltaT;
    car_i.curr_x = (motor[0].curr_speed + motor[2].curr_speed - motor[1].curr_speed - motor[3].curr_speed) / 4.0f;
    car_i.curr_y = (motor[0].curr_speed + motor[1].curr_speed + motor[2].curr_speed + motor[3].curr_speed) / 4.0f;
    car_i.pos_x += (car_i.pre_x + car_i.curr_x) / 2 * car_i.delta;
    car_i.pos_y += (car_i.pre_y + car_i.curr_y) / 2 * car_i.delta;
    car_i.pre_x = car_i.curr_x;
    car_i.pre_y = car_i.curr_y;
    return 0;
}

// TODO ���������Ҫ������壬��û�о��������
/**
 * @brief  �趨�˶�����
 *
 * @param T  ����T
 * @param deltaT ��ʱ������
 * @param tar_pos  Ŀ�����
 * @return int
 */
int pos_set(double T, float deltaT, float x, float y)
{

    float vel_result_x = x_vel_planned(T, deltaT, fabs(x));
    float vel_result_y = y_vel_planned(T, deltaT, fabs(y));
    // float x_, y_;

    float pid_err_x, pid_err_y;
    pid_err_x = pid_pos(&pos[0], vel_result_x, fabs(car_i.pos_x));
    pid_err_y = pid_pos(&pos[1], vel_result_y, fabs(car_i.pos_y));
    // pid_err[0] = pid_pos(&pos[0], vel_result_x, fabs(motor[i].curr_pos));
    // vel_set((pid_err[i] + vel_p_.res_v) * cosf(theta), (pid_err[i] + vel_p_.res_v) * sinf(theta), 0.0f, i);
    if (x == 0 && y != 0)
        for (size_t i = 0; i < 4; i++)
            vel_set(0.0f, y / fabs(y) * (pid_err_y + vel_p_.res_v_y), 0.0f, i);
    else if (y == 0 && x != 0)
        for (size_t i = 0; i < 4; i++)
            vel_set(x / fabs(x) * (pid_err_x + vel_p_.res_v_x), 0.0f, 0.0f, i);
    else if (x == 0 && y == 0)
        for (size_t i = 0; i < 4; i++)
            vel_set(0.0f, 0.0f, 0.0f, i);
    else
        for (size_t i = 0; i < 4; i++)
            vel_set(x / fabs(x) * (pid_err_x + vel_p_.res_v_x), y / fabs(y) * (pid_err_y + vel_p_.res_v_y), 0.0f, i);

    return 0;
}
