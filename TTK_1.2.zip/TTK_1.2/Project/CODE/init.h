#ifndef _INIT_H
#define _INIT_H
int all_init(void);
#endif