#ifndef _PID_H
#define _PID_H
typedef struct
{
    float kp;
    float ki;
    float kd;

    float kis;

    float deltaT;
    float range;

    float i;
    float prev;
} pid_t;
void pid_init(pid_t *pid, float kp, float ki, float kd, float kis, float deltaT, float range);
float pid_vel(pid_t *pid, float target, float curr);
float pid_pos(pid_t *pid, float target, float curr);
float pid_diff(pid_t *pid, float target, float curr);
float pid_image_x(pid_t *pid, float target, float curr);
float pid_image_y(pid_t *pid, float target, float curr);
float pid_zzf(pid_t *pid, float target, float curr);
float pid_yellow(pid_t *pid, float target, float curr);

#endif