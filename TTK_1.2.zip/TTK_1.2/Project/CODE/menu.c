#include "headfile.h"
#include "menu.h"
extern int temp;
menu_t menu_table[4] =
    {

        {0, 0, 0, 1, 0, (*thre_change)},
        {1, 1, 1, 0, 0, (*zzf_image)},
};

/**
 * @brief
 *
 */
void zzf_image(void)
{
    lcd_clear(WHITE);
    lcd_showint32(60, 2, temp, 3);
    lcd_showstr(0, 3, "open");
}

void thre_change(void)
{
    lcd_clear(WHITE);
    // lcd_showint32(60, 2, temp, 3);
    lcd_showstr(0, 2, "thre");
}