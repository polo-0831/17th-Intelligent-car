#include "headfile.h"
#include "init.h"
#include "motor.h"
#include "encoder.h"
#include "pid.h"
#include "MG3512.h"
#include "art.h"
#include "pid.h"

extern uint8 uart1_buff;
extern lpuart_transfer_t uart1_receivexfer;
extern lpuart_handle_t uart1_g_lpuartHandle;

extern uint8 uart4_buff;
extern lpuart_transfer_t uart4_receivexfer;
extern lpuart_handle_t uart4_g_lpuartHandle;

extern uint8 uart8_buff;
extern lpuart_transfer_t uart8_receivexfer;
extern lpuart_handle_t uart8_g_lpuartHandle;

extern pid_t vel[4];
extern pid_t diff[4];
extern pid_t pos[2];
extern pid_t image_x_pid;
extern pid_t image_y_pid;
extern pid_t zzf;
/**
 * @brief Ӳ����ʼ��
 *
 * @return int
 */
int all_init(void)
{
  board_init(); //��ر��������������ڳ�ʼ��MPU ʱ�� ���Դ���
  //�ȴ���ʼ��Ӳ����Ϣ
  systick_delay_ms(500);
  //����͵������ʼ��
  Elec_and_3512_Init();
  // TFT��Ļ
  lcd_init();
  lcd_clear(WHITE);
  lcd_showstr(0, 1, "Initializing...");
  //�����ʼ��
  motor_init();
  //��������ʼ��
  encoder_init();
  // IO�ж�
  gpio_interrupt_init(C4, RISING, GPIO_INT_CONFIG);
  gpio_interrupt_init(C26, RISING, GPIO_INT_CONFIG);
  gpio_interrupt_init(C27, RISING, GPIO_INT_CONFIG);
  gpio_interrupt_init(C31, RISING, GPIO_INT_CONFIG);

  //���ڳ�ʼ��
  uart_init(USART_1, 115200, UART1_TX_B12, UART1_RX_B13);        // openart1�����ݣ�΢����ģ�ͣ���ͼ��
  uart_init(USART_4, 115200, UART4_TX_C16, UART4_RX_C17);        // openart2�����ݸı�ģʽ
  uart_init(DATA_SEND_UART, 115200, UART8_TX_D16, UART8_RX_D17); // ��ί������

  //�������ȼ�
  NVIC_SetPriority(LPUART1_IRQn, 1);
  NVIC_SetPriority(LPUART4_IRQn, 2);
  NVIC_SetPriority(LPUART8_IRQn, 3);
  NVIC_SetPriority(PIT_IRQn, 4);
  NVIC_SetPriority(GPIO2_Combined_0_15_IRQn, 15);
  NVIC_SetPriority(GPIO2_Combined_16_31_IRQn, 15);

  //�򿪴����ж�
  uart_rx_irq(USART_1, 1);
  uart_rx_irq(USART_4, 1);
  uart_rx_irq(USART_8, 1);
  uart1_receivexfer.dataSize = 1;
  uart1_receivexfer.data = &uart1_buff;
  uart_set_handle(USART_1, &uart1_g_lpuartHandle, openart1_callback, NULL, 0, uart1_receivexfer.data, 1);
  uart4_receivexfer.dataSize = 1;
  uart4_receivexfer.data = &uart4_buff;
  uart_set_handle(USART_4, &uart4_g_lpuartHandle, openart2_callback, NULL, 0, uart4_receivexfer.data, 1);
  uart8_receivexfer.dataSize = 1;
  uart8_receivexfer.data = &uart8_buff;
  uart_set_handle(USART_8, &uart8_g_lpuartHandle, wifi8_callback, NULL, 0, uart8_receivexfer.data, 1);
  //��ʱ����ʼ��
  pit_init();
  //�ٶ�PID��ʼ��
  for (size_t i = 0; i < 4; i++)
  {
    pid_init(&vel[i], 17000, 230000, 135, 5e-3, 0.005f, 0.50f * PWM_MAX);
  }
  //�ٶȻ�ƫ��PID ֱ��
  pid_init(&diff[0], 10.0f, 0.3f, 0.0f, 5e-3, 0.005f, 0.10f * PWM_MAX);
  pid_init(&diff[1], 10.0f, 0.3f, 0.0f, 5e-3, 0.005f, 0.10f * PWM_MAX);
  //�ٶȻ�ƫ��PID ����
  pid_init(&diff[2], 15.0f, 0.0f, 0.0f, 5e-3, 0.005f, 0.10f * PWM_MAX);
  pid_init(&diff[3], 15.0f, 0.0f, 0.0f, 5e-3, 0.005f, 0.10f * PWM_MAX);
  // pid_init(&diff[2], 150.0f, 0.0f, 0.0f, 5e-3, 0.005f, 0.10f * PWM_MAX);
  // pid_init(&diff[3], 150.0f, 0.0f, 0.0f, 5e-3, 0.005f, 0.10f * PWM_MAX);
  //  pid_init(&diff[2], 120.0f, 0.0f, 0.0f, 5e-3, 0.005f, 0.10f * PWM_MAX);
  //  pid_init(&diff[3], 120.0f, 0.0f, 0.0f, 5e-3, 0.005f, 0.10f * PWM_MAX);
  // ͼ��΢��PID
  pid_init(&image_x_pid, 0.003f, 0.0f, 0.00f, 0, 0.01f, 0.8f);
  pid_init(&image_y_pid, 0.003f, 0.0f, 0.00f, 0, 0.01f, 0.8f);
  //�����PID
  pid_init(&image_y_pid, 0.3f, 0.0f, 0.00f, 0, 0.01f, 1.0f);
  for (size_t i = 0; i < 2; i++)
  {
    pid_init(&pos[i], 8.0f, 0.0f, 0.0f, 0, 0.01f, 3.5f);
  }
  lcd_clear(WHITE);
  return 0;
}