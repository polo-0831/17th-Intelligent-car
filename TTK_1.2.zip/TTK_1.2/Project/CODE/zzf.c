#include "headfile.h"
#include "zzf.h"
#include "pid.h"
#include "art.h"
extern pid_t zzf;
/**
 * @brief 总钻风矫正车身
 *
 * @param tar
 * @param curr
 * @return int
 */
int zzf_correct(float tar, float curr)
{
    float pid_err = pid_zzf(&zzf, tar, curr);
    for (size_t i = 0; i < 4; i++)
    {
        image_vel_set(0.0f, 0.0f, pid_err);
    }
    return 0;
}