#ifndef _MG3512_H
#define _MG3512_H

#define MG3512 PWM4_MODULE2_CHA_C30 //����ӿ�
#define Elec_mag B10                //������ӿ�
typedef struct
{
    uint32_t t;
    float time;
    int step;
    bool end_flag;
} mg3512_t;

void Elec_and_3512_Init(void);
int Pick(float T, float deltaT, int type);
#endif
