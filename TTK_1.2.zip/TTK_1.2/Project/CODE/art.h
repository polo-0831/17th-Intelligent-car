#ifndef _ART_H
#define _ART_H
#define DATA_SEND_UART USART_8
typedef enum
{
    CATEGORY_NULL = 0, //�����
    DOG = 7,           //��
    HORSE = 8,         //��
    CAT = 9,           //è
    CATTLE = 10,       //ţ
    PIG = 11,          //��
    ORANGE = 13,       //����
    APPLE = 14,        //ƻ��
    DURIAN = 15,       //����
    GRAPE = 16,        //����
    BANANA = 17,       //�㽶
    TRAINS = 19,       //��
    STEAMSHIP = 20,    //�ִ�
    PLANE = 21,        //�ɻ�
    CAR = 22,          //С�γ�
    COACH = 23,        //��ͳ�
    CARRY = 54,        //����
} category_enum;
typedef struct
{
    float soft_vx;
    float soft_vy;
    float soft_w;
} img_vel_t;
int16_t Speed_slew(float *slewVal, float refVal, float slewRate_speedup, float slewRate_speeddown);
void image_vel_set(float vx, float vy, float w);
void openart1_callback(LPUART_Type *base, lpuart_handle_t *handle, status_t status, void *userData);
void openart2_callback(LPUART_Type *base, lpuart_handle_t *handle, status_t status, void *userData);
void wifi8_callback(LPUART_Type *base, lpuart_handle_t *handle, status_t status, void *userData);
int UART_printf(UARTN_enum uartn, const char *fmt, ...);
void send_msg(UARTN_enum uartn, uint16 second, uint16 msecond, uint8 pos_x, uint8 pos_y, category_enum cg);
void Fine_Tuning(float tar_x, float tar_y, float curr_x, float curr_y);
#endif