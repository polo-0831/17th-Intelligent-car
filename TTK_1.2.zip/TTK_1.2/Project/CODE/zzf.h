#ifndef _ZZF_H
#define _ZZF_H
int zzf_correct(float tar, float curr);
#endif