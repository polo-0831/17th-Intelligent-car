#ifndef _MENU_H
#define _MENU_H

#define key_up C4
#define key_down C26
#define key_enter C27
#define key_back C31
typedef struct
{
    unsigned char current;
    unsigned char up;    //上键
    unsigned char down;  //下键
    unsigned char enter; //确认键
    unsigned char back;  //返回键
    void (*current_operation)(void);
} menu_t;
//显示图像函数
void zzf_image(void);
void thre_change(void);
//执行索引到的函数

#endif